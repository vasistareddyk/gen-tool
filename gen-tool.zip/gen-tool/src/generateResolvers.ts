import * as fs from "fs";
import * as hbs from "handlebars";
import { camelize, pluralize, singularize } from "inflection";
import * as path from "path";
import to from 'await-to-js';

export class GenerateResolvers {
  generateResolver(data: any) {
    const resolversTemplate = `import { Args, Info, Mutation, Query, Resolver} from '@nestjs/graphql-federated';
import { {{Name}}Service } from './{{#capitalize 'low_first_letter' Name}}{{/capitalize}}.service';
import { IGenerated{{Name}} } from './{{#capitalize 'low_first_letter' Name}}{{/capitalize}}.generated.interface';

@Resolver('{{Name}}')
export class {{Name}}Resolver {

constructor(private readonly {{ServiceName}}Service: {{Name}}Service) {}

{{#each Query}}
@Query('{{@key}}')
async {{@key}}(@Args() args, @Info() info): Promise<IGenerated{{this}}> {
  return await this.{{../ServiceName}}Service.{{@key}}(args, info);
}

{{/each}}
{{#each Mutation}}
@Mutation('{{@key}}')
async {{@key}}(@Args() args, @Info() info): Promise<IGenerated{{this}}> {
  return await this.{{../ServiceName}}Service.{{@key}}(args, info);
}

{{/each}}
}
`;

    const resolverResult = hbs.compile(resolversTemplate)(data);

    const filenameArray = data.Name.match(/[A-Z][a-z]+/g);

    let filename = filenameArray.map(element => {
      return camelize(element, 'low_first_letter')
    }).join('-')

    const nameOfFile = path.join(process.cwd(),`${filename}.generated.resolver.ts`);

    fs.writeFile(nameOfFile, resolverResult, err => {
      if (err) {
        throw err;
      }
    });

    const nameOfService = path.join(process.cwd(),`${filename}.service.ts`);
    const nameOfResolver = path.join(process.cwd(),`${filename}.resolver.ts`);

    fs.readdir(process.cwd(), (err, files) => {
      const modelNames =files.filter(el => /\.service.ts$/.test(el))
      if(modelNames[0]){
        return
      }
      else{
        fs.writeFile(nameOfService, resolverResult, err => {
          if (err) {
            throw err;
          }
        });
        fs.writeFile(nameOfResolver, resolverResult, err => {
          if (err) {
            throw err;
          }
        });
      }
    })

    fs.appendFile(
      path.join(process.cwd(), "history.txt"),
      `${camelize(data.Name, "low_first_letter")} resolver created\n`,
      err => {
        if (err) {
          throw err;
        }
      }
    );
  }
}
