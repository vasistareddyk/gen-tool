#!/usr/bin/env node
import { AutoGenerate } from './generate';

class GenerateCli{
    private generateSchema: AutoGenerate = new AutoGenerate()
    
    start(){
        this.generateSchema.generateSchema();
    }
}

new GenerateCli().start()