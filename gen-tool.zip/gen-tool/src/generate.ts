import * as path from "path";
import * as data from "./models";
import * as fs from "fs";
import * as hbs from "handlebars";
import { camelize, pluralize, singularize } from "inflection";
import { GenerateGraphQl } from "./generateGraphql";
import { GenerateMongooseSchema } from "./generateMongoose";
import { GenerateMongooseInterface } from "./generateInterface";
import { GenerateResolvers } from "./generateResolvers";


interface IResolverData {
  Name: string;
  ServiceName: string;
  Query: IQuery;
  Mutation: IMutation;
}

interface IQuery {
  [key: string]: any;
}

interface IMutation {
  [key: string]: any;
}

export class AutoGenerate {
  private generateGraphQl: GenerateGraphQl = new GenerateGraphQl();
  private generateMongoose: GenerateMongooseSchema = new GenerateMongooseSchema();
  private generateMongooseInterface: GenerateMongooseInterface = new GenerateMongooseInterface();
  private generateResolvers: GenerateResolvers = new GenerateResolvers();
  //private model = data.default.models;
  modelsInDirectory:any = [];
  model:any ;
  constructor() {

    hbs.registerHelper("ifEquals", (arg1, arg2, options) => {
      return arg1 === arg2 ? options.fn(this) : options.inverse(this);
    });

    hbs.registerHelper("ifNotEquals", (arg1, arg2, options) => {
      if (arg1 !== arg2) {
        return options.fn(this);
      }
      return options.inverse(this);
    });

    // hbs.registerHelper('removeChar', (arg1, arg2, options) => {
    //   return options.fn(this).replace(/!/g, '');
    // });

    hbs.registerHelper("removeChar", options => {
      return options.fn(this).replace(/!/g, "");
    });

    hbs.registerHelper("ifContains", (arg1, arg2, options) => {
      return arg1.includes(arg2) ? options.fn(this) : options.inverse(this);
    });

    hbs.registerHelper("ifArray", (arg1, options) => {
      return Array.isArray(arg1) ? options.fn(this) : options.inverse(this);
    });

    hbs.registerHelper("ifNotArray", (arg1, options) => {
      return Array.isArray(arg1) ? options.inverse(this) : options.fn(this);
    });

    hbs.registerHelper("replaceEntity", options => {
      return options.fn(this).replace(/&quot;/g, "'");
    });

    hbs.registerHelper("capitalize", (arg1, arg2, options) => {
      return camelize(arg2, arg1);
    });

    hbs.registerHelper("capitalizeplural", (arg1, arg2, options) => {
      if(pluralize(arg2) === arg2){
        return `${camelize(arg2,arg1)}s`
      }
      return camelize(pluralize(arg2), arg1);
    });
  }

  /**
   * generateSchema
   * default function
   */
  generateSchema() {
    fs.appendFile(
      path.join(process.cwd(), "history.txt"),
      `\n${new Date()}\n`,
      err => {
        if (err) {
          throw err;
        }
      }
    );
    
    fs.readdir(process.cwd(), (err, files) => {
      const modelNames =files.filter(el => /\.model.json$/.test(el))
      if(modelNames[0]){
      this.model = JSON.parse(fs.readFileSync(modelNames[0], 'utf8'))
      this.generateData(this.model);
      }
      else{
        console.log('No model Found')
        return 
      }
    })
  }

  /**
   * generateMangooseData
   * generate structure for mangoose
   */
  generateData(modelData) {
    const models = Object.keys(modelData).map(typeName => ({
      name: typeName,
      fields: modelData[typeName]
    }));

    models.map(fields => {
      // const dir = `./${camelize(pluralize(fields.name), "low_first_letter")}`;
      // const gSchema = fields;
      // if (!fs.existsSync(dir)) {
      //   fs.mkdirSync(dir);
      //   this.generateGraphQl.generateSchema(gSchema);
      //   this.generateNewModelData(fields);
      // } else {
      //   this.generateGraphQl.generateSchema(gSchema);
      //   this.generateNewModelData(fields);
      // }
      const gSchema = fields;
      this.generateGraphQl.generateSchema(gSchema);
      this.generateNewModelData(fields);
    });
  }

  /**
   * generateNewModelData
   * generate new model for ease of loop in hbs
   * @param inputData
   */
  generateNewModelData(inputData) {
    Object.keys(inputData.fields).map(field => {
      if (inputData.fields[field] !== "id") {
        if (inputData.fields[field].hasOwnProperty("relation")) {
          if(inputData.fields[field].relationtype == 'one'){
            inputData.fields[field] = [
              '{ type: mongoose.Schema.Types.ObjectId, ref: "' +
                inputData.fields[field].relation.replace(/!/g, "") +
                '" }'
            ];
          }else{
          inputData.fields[field] = [
            '[{ type: mongoose.Schema.Types.ObjectId, ref: "' +
              inputData.fields[field].relation.replace(/!/g, "") +
              '" }]'
          ];
        }
        } else {
          if (inputData.fields[field].hasOwnProperty("type")) {
            let newObj = {};
            newObj = inputData.fields[field];
            // tslint:disable-next-line: no-string-literal
            newObj["type"] = inputData.fields[field].type.replace(/!/g, "");
            if (inputData.fields[field].type.includes("!")) {
              // tslint:disable-next-line: no-string-literal
              newObj["required"] = "true";
            }
            if (inputData.fields[field].hasOwnProperty("unique")) {
              // tslint:disable-next-line: no-string-literal
              newObj["unique"] = "true";
            }
            inputData.fields[field] = newObj;
          }
        }
      }
    });
    this.generateMongoose.generateSchema(inputData);
    this.generateMongooseInterface.generateInterface(inputData);
    this.resolverData(inputData);
  }

  resolverData(modelData) {
    const { name } = modelData;
    const mData: IResolverData = {
      Name: name,
      ServiceName: camelize(name, "low_first_letter"),
      Query: {
        [`${camelize(pluralize(name), "low_first_letter")}`]: `${name}[]`,
        [`${camelize(name, "low_first_letter")}`]: `${name}`
      },
      Mutation: {
        [`create${name}`]: name,
        [`update${name}`]: name,
        [`delete${name}`]: name
      }
    };

    this.generateResolvers.generateResolver(mData);
  }
}
