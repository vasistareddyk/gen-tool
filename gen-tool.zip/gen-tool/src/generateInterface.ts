import * as fs from "fs";
import * as hbs from "handlebars";
import { camelize, pluralize, singularize } from "inflection";
import * as path from "path";

export class GenerateMongooseInterface {
  generateInterface(data: any) {
    const nI = data;

    Object.keys(nI.fields).map(field => {
      if (Array.isArray(nI.fields[field])) {
        delete nI.fields[field];
      }
    });

    const schemaData = nI;

    const mongooseInterface = `import { Document } from 'mongoose';

export interface IGenerated{{name}} extends Document {
    readonly id?: string;
    {{#each fields}}
    {{#ifNotEquals @key "id"}}
    readonly {{@key}}{{#if ../required}}?{{/if}}: {{#capitalize 'low_first_letter' ../type}}{{/capitalize}};
    {{/ifNotEquals}}
    {{/each}}
    readonly createdBy: string;
    readonly updatedBy: string;
    readonly createdAt?: string;
    readonly updatedAt?: string;
}
`;

    const mongooseTemplate = hbs.compile(mongooseInterface);

    const mongooseModelData: any = schemaData;

    const mongooseResult = mongooseTemplate(mongooseModelData);

    const filenameArray = data.name.match(/[A-Z][a-z]+/g);

    let filename = filenameArray.map(element => {
      return camelize(element, 'low_first_letter')
    }).join('-')


    const pluralizeName = camelize(pluralize(data.name), "low_first_letter");

    const nameOfFile = path.join(
      process.cwd(),
      `${filename}.generated.interface.ts`
    );

    fs.writeFile(nameOfFile, mongooseResult, err => {
      if (err) {
        throw err;
      }
    });

    fs.appendFile(
      path.join(process.cwd(), "history.txt"),
      `${camelize(data.name, "low_first_letter")} mongoose interface created\n`,
      err => {
        if (err) {
          throw err;
        }
      }
    );
  }
}
