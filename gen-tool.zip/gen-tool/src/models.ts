export default {
  models: {
    User: {
      id: {
        type: 'ID!',
        unique: 'true',
      },
      email: {
        type: 'String!',
        unique: 'true',
      },
      password: {
        type: 'String!',
      },
      firstName: {
        type: 'String!',
      },
      lastName: {
        type: 'String!',
      },
      mobile: {
        type: 'String!',
      },
      realm: {
        type: 'String!',
      },
      metaData: {
        type: 'String',
      },
      lastLogin: {
        type: 'String!',
      },
      isActive: {
        type: 'Boolean!',
      },
      logs: {
        type: 'relation',
        relation: 'Log!',
      },
    },
    Log: {
      id: {
        type: 'ID!',
        unique: 'true',
      },
      loggedInDate: {
        type: 'String!',
      },
      loggedOutDate: {
        type: 'String!',
      },
      ipAddress: {
        type: 'String!',
      },
      users: {
        type: 'relation',
        relation: 'User!',
        provides: 'User',
      },
      extends: [{ model: 'User' }, { model: 'Invite' }],
    },
    Invite: {
      id: {
        type: 'ID!',
        unique: 'true',
      },
      email: {
        type: 'String!',
      },
      token: {
        type: 'String!',
      },
    },
  },
};
