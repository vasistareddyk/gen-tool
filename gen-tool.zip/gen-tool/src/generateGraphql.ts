import { GenerateResolvers } from './generateResolvers';
import * as fs from 'fs';
import * as hbs from 'handlebars';
import { camelize, pluralize, singularize } from 'inflection';
import * as path from 'path';

export class GenerateGraphQl {
  generateSchema(data: any) {
    const schemas = `type Query {
   {{#capitalize 'low_first_letter' name}}{{/capitalize}}(where:{{name}}WhereUniqueInput!):{{name}}
   {{#capitalizeplural 'low_first_letter' name}}{{/capitalizeplural}}:[{{name}}!]
}

type Mutation {
    create{{name}}(data:create{{name}}Input!):{{name}}
    update{{name}}(data:update{{name}}Input, where: {{name}}WhereUniqueInput!):{{name}}
    delete{{name}}(where: {{name}}WhereUniqueInput!):{{name}}
}

type {{name}} @key(fields: "id") {
  {{#each fields}}
  {{#if type}}
  {{#unless relation}}
    {{@key}} : {{type}} {{#if provides}} @provides(fields: "id"){{/if}}
    {{/unless}}
    {{#if relation}}
    {{#ifEquals relationtype "one"}}
    {{@key}} : {{../relation}} @provides(fields: "id")
    {{/ifEquals}}
    {{#ifEquals relationtype "many"}}
    {{@key}} : [{{../relation}}]! @provides(fields: "id")
    {{/ifEquals}}
{{/if}}
    {{/if}}
  {{/each}}
    createdAt: DateTime!
    updatedAt: DateTime
    createdBy: User! {{#each fields}}{{#ifEquals @key "extends"}} @provides(fields: "id") {{/ifEquals}}{{/each}}
    updatedBy: User! {{#each fields}}{{#ifEquals @key "extends"}} @provides(fields: "id") {{/ifEquals}}{{/each}}
}

input create{{name}}Input {
  {{#each fields}}
  {{#if type}}
  {{#unless relation}}
    {{@key}} : {{type}}
  {{/unless}}
  {{/if}}
  {{#if relation}}
    {{@key}} : {{relation}}
  {{/if}}
  {{/each}}
}

input update{{name}}Input {
  {{#each fields}}
  {{#if type}}
  {{#unless relation}}
    {{@key}} : {{type}}
    {{/unless}}
    {{/if}}
  {{/each}}
}

input {{name}}WhereUniqueInput {
  {{#each fields}}
  {{#if unique}}
    {{@key}} : {{type}}
    {{/if}}
  {{/each}}
}

input {{name}}WhereInput {
  {{#each fields}}
  {{#if type}}
  {{#unless relation}}
    {{@key}} : {{#removeChar}}{{../type}}{{/removeChar}}
  {{/unless}}
  {{/if}}
  {{/each}}
}

{{#each fields}}
{{#ifEquals @key "extends"}}
{{#each ../this}}
extend type {{model}} @key(fields: "id") {
  id: ID! @external
  {{#capitalizeplural 'low_first_letter' ../../../name }}{{/capitalizeplural}}: [{{../../../name}}]
}
{{/each}}
{{/ifEquals}}
{{/each}}

scalar DateTime

`;

    const template = hbs.compile(schemas);

    const modeldata: any = data;

    const result = template(modeldata);

    const filenameArray = data.name.match(/[A-Z][a-z]+/g);

    let filename = filenameArray.map(element => {
      return camelize(element, 'low_first_letter')
    }).join('-')

    const nameOfFile = path.join(process.cwd(),`${filename}.generated.graphql`);

    fs.writeFile(nameOfFile, result, err => {
      if (err) {
        throw err;
      }
    });

    fs.appendFile(
      path.join(process.cwd(), 'history.txt'),
      `${camelize(data.name, 'low_first_letter')} graphql schema created\n`,
      err => {
        if (err) {
          throw err;
        }
      },
    );
  }
}
