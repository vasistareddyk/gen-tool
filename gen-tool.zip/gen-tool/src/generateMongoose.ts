import * as fs from "fs";
import * as hbs from "handlebars";
import { camelize, pluralize, singularize } from "inflection";
import * as path from "path";

export class GenerateMongooseSchema {
  generateSchema(data: any) {
    const schemaData = data;
    const mongooseSchema = `import * as mongoose from 'mongoose';

export const {{name}}GeneratedSchema = new mongoose.Schema({
{{#each fields}}
{{#ifNotEquals @key "id"}}
{{#if ../type}}
    {{@key}}: {
        {{#each ../this}}
        {{@key}}: {{this}},
        {{/each}}
    },
{{else}}
{{#ifArray ../this}}
{{#ifNotEquals @key "extends"}}
    {{@key}} : {{#each ../this}}{{#replaceEntity}}{{../this}}{{/replaceEntity}}{{/each}},
    {{/ifNotEquals}}
{{/ifArray}}
{{/if}}
{{/ifNotEquals}}
{{/each}}
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
},
{
    timestamps: true,
});
`;

    const mongooseTemplate = hbs.compile(mongooseSchema);

    const mongooseResult = mongooseTemplate(schemaData);

    const filenameArray = data.name.match(/[A-Z][a-z]+/g);

    let filename = filenameArray.map(element => {
      return camelize(element, 'low_first_letter')
    }).join('-')

    const nameOfFile = path.join(
      process.cwd(),
      `${filename}.generated.schema.ts`
    );

    fs.writeFile(nameOfFile, mongooseResult, err => {
      if (err) {
        throw err;
      }
    });

    fs.appendFile(
      path.join(process.cwd(), "history.txt"),
      `${camelize(data.name, "low_first_letter")} Mongoose schema created\n`,
      err => {
        if (err) {
          throw err;
        }
      }
    );
  }
}
